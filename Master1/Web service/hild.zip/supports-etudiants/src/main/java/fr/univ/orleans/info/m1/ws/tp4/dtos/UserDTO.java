package fr.univ.orleans.info.m1.ws.tp4.dtos;

import org.springframework.web.bind.annotation.RequestParam;

public class UserDTO {

    String username;
    String[] roles;


    public UserDTO() {
    }
    public UserDTO(String username, String[] roles) {
        this.username = username;
        this.roles = roles;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String[] getRoles() {
        return roles;
    }

    public void setRoles(String[] roles) {
        this.roles = roles;
    }
}
