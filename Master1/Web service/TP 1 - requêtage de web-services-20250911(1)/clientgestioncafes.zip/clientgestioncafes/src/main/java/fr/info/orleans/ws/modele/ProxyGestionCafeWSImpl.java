package fr.info.orleans.ws.modele;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.format.DateTimeFormatter;
import java.util.Collection;

public class ProxyGestionCafeWSImpl implements ProxyGestionCafeWS {


    private ObjectMapper mapper = new ObjectMapper();
    //private XmlMapper mapperXML = new XmlMapper();
    private HttpClient client = HttpClient.newHttpClient();



    @Override
    public String inscription(String emailText, String nomText, String prenomText) throws ConflitEmailException, DonneesIncompletesException {
	return null;
    }



    @Override
    public UtilisateurDTO connexion(String cleSecreteText) throws MauvaiseCleSecreteException {
        return null;

    }

    @Override
    public Collection<RechargeCafeDTO> getRecharges(String cleSecrete, Filtre filtreCourant) {

        return null;
    }

    @Override
    public String creerRecharge(String cleSecrete, int nbKilos) throws PoidsIncorrectException {

        return null;

    }
}
